'use strict';
/*
 * Mauli College Portal - backend server
 * Zero dependencies. Needs Node.js 22.13 or newer (uses the built-in SQLite module).
 *
 *   node server.js                          start the server
 *   node server.js reset-superadmin <pass>  set a new Super Admin password and exit
 */
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const zlib = require('node:zlib');
const { DatabaseSync } = require('node:sqlite');

const PORT = Number(process.env.PORT) || 3000;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const PUBLIC_DIR = path.join(__dirname, 'public');
const SESSION_HOURS = Number(process.env.SESSION_HOURS) || 12;

fs.mkdirSync(DATA_DIR, { recursive: true });
const db = new DatabaseSync(path.join(DATA_DIR, 'mauli.db'));
db.exec(`
PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS kv(key TEXT PRIMARY KEY, value TEXT NOT NULL, version INTEGER NOT NULL DEFAULT 1, updated_at TEXT NOT NULL, updated_by TEXT);
CREATE TABLE IF NOT EXISTS logins(key TEXT PRIMARY KEY, salt TEXT NOT NULL, hash TEXT NOT NULL, updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS accounts(username TEXT PRIMARY KEY, display TEXT NOT NULL, role TEXT NOT NULL, dept TEXT, salt TEXT NOT NULL, hash TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS sessions(id TEXT PRIMARY KEY, login_key TEXT NOT NULL, role TEXT NOT NULL, sub TEXT, username TEXT, display TEXT, is_account INTEGER NOT NULL DEFAULT 0, expires INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS settings(k TEXT PRIMARY KEY, v TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY AUTOINCREMENT, at TEXT NOT NULL, actor TEXT, action TEXT NOT NULL, detail TEXT);
`);

/* ---------- constants ---------- */
const MAIN = ['Super Admin', 'Chairman', 'Principal', 'Academic Coordinator', 'IQAC', 'TPO', 'Registrar', 'HOD - CSE', 'HOD - IT', 'HOD - ENTC', 'HOD - Civil', 'HOD - Mechanical', 'HOD - Electrical', 'HOD - ASH', 'R & D Coordinator', 'Sports Director', 'NSS Incharge', 'Faculty', 'Other'];
const OTHERS = ['Cultural Coordinator', 'Career Guidance Cell', 'Alumni Coordinator', 'NAAC Coordinator', 'NBA Coordinator', 'ED Cell Coordinator', 'Librarian', 'Rector', 'Ph.D Coordinator', 'Admission Coordinator'];
const KEY_RE = /^mauli_[a-z0-9_]{1,60}$/;
const CREDENTIAL_KEYS = new Set(['mauli_admin_accounts', 'mauli_pw_overrides']); // never stored as data
const SUPERADMIN_ONLY_KEYS = new Set(['mauli_dashboard_custom']);

/* ---------- helpers ---------- */
const now = () => new Date().toISOString();
const sha = (s) => crypto.createHash('sha256').update(s).digest('hex');
const scrypt = (pw, salt) => new Promise((res, rej) => crypto.scrypt(pw, salt, 64, { N: 16384, r: 8, p: 1 }, (e, k) => (e ? rej(e) : res(k))));
async function hashPw(pw) { const salt = crypto.randomBytes(16); const h = await scrypt(pw, salt); return { salt: salt.toString('hex'), hash: h.toString('hex') }; }
async function checkPw(pw, salt, hash) {
  const h = await scrypt(pw, Buffer.from(salt, 'hex')); const e = Buffer.from(hash, 'hex');
  return e.length === h.length && crypto.timingSafeEqual(e, h);
}
const randomPw = () => crypto.randomBytes(9).toString('base64url');
const getSetting = (k) => { const r = db.prepare('SELECT v FROM settings WHERE k=?').get(k); return r ? r.v : null; };
const putSetting = (k, v) => db.prepare('INSERT INTO settings(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v').run(k, v);
const audit = (actor, action, detail) => db.prepare('INSERT INTO audit(at,actor,action,detail) VALUES(?,?,?,?)').run(now(), actor || '-', action, detail || '');

/* ---------- first-run secrets ---------- */
async function initSecrets() {
  if (!getSetting('default_hash')) {
    let pw = process.env.DEFAULT_PASSWORD, generated = false;
    if (!pw) { pw = randomPw(); generated = true; }
    const h = await hashPw(pw);
    putSetting('default_salt', h.salt); putSetting('default_hash', h.hash);
    putSetting('initial_salt', h.salt); putSetting('initial_hash', h.hash);
    if (generated) console.log(`\n  FIRST RUN: password for every login (except Super Admin): ${pw}\n  Save it now. It is shown only once. Super Admin can change it later.\n`);
  }
  if (!db.prepare('SELECT 1 FROM logins WHERE key=?').get('Super Admin')) {
    let pw = process.env.SUPERADMIN_PASSWORD, generated = false;
    if (!pw) { pw = randomPw(); generated = true; }
    const h = await hashPw(pw);
    db.prepare('INSERT INTO logins(key,salt,hash,updated_at) VALUES(?,?,?,?)').run('Super Admin', h.salt, h.hash, now());
    if (generated) console.log(`\n  FIRST RUN: Super Admin password: ${pw}\n  Save it now. It is shown only once.\n`);
  }
}

/* ---------- sessions ---------- */
function parseCookies(req) {
  const o = {};
  (req.headers.cookie || '').split(';').forEach((p) => { const i = p.indexOf('='); if (i > 0) { try { o[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim()); } catch (e) { /* ignore */ } } });
  return o;
}
function getSession(req) {
  const t = parseCookies(req).mauli_sid; if (!t) return null;
  const row = db.prepare('SELECT * FROM sessions WHERE id=?').get(sha(t)); if (!row) return null;
  if (row.expires < Date.now()) { db.prepare('DELETE FROM sessions WHERE id=?').run(row.id); return null; }
  return row;
}
const isHttps = (req) => (req.headers['x-forwarded-proto'] || '').split(',')[0].trim() === 'https' || !!req.socket.encrypted;
function createSession(req, res, s) {
  const token = crypto.randomBytes(32).toString('hex');
  db.prepare('INSERT INTO sessions(id,login_key,role,sub,username,display,is_account,expires) VALUES(?,?,?,?,?,?,?,?)')
    .run(sha(token), s.key, s.role, s.sub || '', s.username || '', s.display || '', s.isAccount ? 1 : 0, Date.now() + SESSION_HOURS * 3600e3);
  const cookie = `mauli_sid=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${SESSION_HOURS * 3600}${isHttps(req) ? '; Secure' : ''}`;
  res.setHeader('Set-Cookie', cookie);
}
const clearCookie = (res) => res.setHeader('Set-Cookie', 'mauli_sid=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0');
function dropSessions(where, args, exceptId) {
  db.prepare(`DELETE FROM sessions WHERE ${where}${exceptId ? ' AND id<>?' : ''}`).run(...args, ...(exceptId ? [exceptId] : []));
}
setInterval(() => { try { db.prepare('DELETE FROM sessions WHERE expires<?').run(Date.now()); } catch (e) { /* ignore */ } }, 3600e3).unref();

/* ---------- rate limiting for failed logins ---------- */
const fails = new Map();
function failCount(k) { const f = fails.get(k); if (!f || f.reset < Date.now()) { fails.delete(k); return 0; } return f.n; }
function addFail(k) { const f = fails.get(k); if (!f || f.reset < Date.now()) fails.set(k, { n: 1, reset: Date.now() + 15 * 60e3 }); else f.n++; }
const clientIp = (req) => ((req.headers['x-forwarded-for'] || '').split(',')[0].trim() || req.socket.remoteAddress || '?');

/* ---------- http utilities ---------- */
const SEC = { 'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY', 'Referrer-Policy': 'same-origin' };
function json(res, code, obj) {
  const b = JSON.stringify(obj);
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...SEC });
  res.end(b);
}
function readBody(req, limit = 30 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    let n = 0; const chunks = [];
    req.on('data', (d) => { n += d.length; if (n > limit) { reject(Object.assign(new Error('Request too large'), { code: 413 })); req.destroy(); return; } chunks.push(d); });
    req.on('end', () => { try { resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {}); } catch (e) { reject(Object.assign(new Error('Invalid JSON'), { code: 400 })); } });
    req.on('error', reject);
  });
}
const loginKeyOf = (role, sub) => (role === 'Faculty' ? 'Faculty:' + sub : role === 'Other' ? sub : role);
const cleanText = (v, max) => String(v == null ? '' : v).replace(/[\u0000-\u001f<>]/g, '').trim().slice(0, max);

/* ---------- static file ---------- */
let indexCache = { mtime: 0, raw: null, gz: null };
function serveIndex(req, res) {
  const file = path.join(PUBLIC_DIR, 'index.html');
  let st; try { st = fs.statSync(file); } catch (e) { res.writeHead(500); res.end('index.html missing'); return; }
  if (indexCache.mtime !== st.mtimeMs) { const raw = fs.readFileSync(file); indexCache = { mtime: st.mtimeMs, raw, gz: zlib.gzipSync(raw) }; }
  const gz = /\bgzip\b/.test(req.headers['accept-encoding'] || '');
  const h = { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-cache', ...SEC };
  if (isHttps(req)) h['Strict-Transport-Security'] = 'max-age=15552000';
  if (gz) h['Content-Encoding'] = 'gzip';
  res.writeHead(200, h); res.end(gz ? indexCache.gz : indexCache.raw);
}

/* ---------- API ---------- */
async function api(req, res, url) {
  const method = req.method, p = url.pathname;
  if (method !== 'GET' && method !== 'HEAD') {
    const origin = req.headers.origin;
    if (origin) { let ok = false; try { ok = new URL(origin).host === req.headers.host; } catch (e) { /* ignore */ } if (!ok) return json(res, 403, { error: 'Cross-site request blocked.' }); }
    if (!/application\/json/i.test(req.headers['content-type'] || '') && method !== 'DELETE') return json(res, 415, { error: 'JSON required.' });
  }

  /* --- public --- */
  if (p === '/api/health') return json(res, 200, { ok: true });

  if (p === '/api/login' && method === 'POST') {
    const b = await readBody(req, 64 * 1024);
    const role = String(b.role || ''), sub = cleanText(b.sub, 120), username = cleanText(b.username, 80).toLowerCase(), password = String(b.password || '');
    if (!MAIN.includes(role) || (role === 'Other' && !OTHERS.includes(sub)) || (role === 'Faculty' && !sub) || !password || password.length > 200) return json(res, 400, { error: 'Choose your role and enter your password.' });
    const key = loginKeyOf(role, sub), ip = clientIp(req);
    if (failCount('ip:' + ip) >= 20 || failCount('key:' + key) >= 40) return json(res, 429, { error: 'Too many failed attempts. Try again in 15 minutes.' });
    const bad = () => { addFail('ip:' + ip); addFail('key:' + key); audit(username || key, 'login-failed', key + ' from ' + ip); return json(res, 401, { error: 'Incorrect password for this login.' }); };

    const acct = username ? db.prepare('SELECT * FROM accounts WHERE username=?').get(username) : null;
    if (acct) {
      const roleOk = acct.role === role || (role === 'Other' && acct.role === sub);
      if (!(await checkPw(password, acct.salt, acct.hash))) return bad();
      if (!roleOk) return json(res, 403, { error: 'Choose the role assigned to this account.' });
      createSession(req, res, { key: 'acct:' + acct.username, role, sub, username: acct.username, display: acct.display, isAccount: true });
      audit(acct.username, 'login', key);
      return json(res, 200, { ok: true });
    }
    const row = db.prepare('SELECT salt,hash FROM logins WHERE key=?').get(key);
    const salt = row ? row.salt : getSetting('default_salt'), hash = row ? row.hash : getSetting('default_hash');
    if (!(await checkPw(password, salt, hash))) return bad();
    createSession(req, res, { key, role, sub, username, display: '' });
    audit(key, 'login', 'ip ' + ip);
    return json(res, 200, { ok: true });
  }

  /* --- everything below needs a session --- */
  const s = getSession(req);
  if (p === '/api/session') {
    if (!s) return json(res, 200, { ok: false });
    return json(res, 200, { ok: true, role: s.role, sub: s.sub, username: s.username, display: s.display, account: !!s.is_account });
  }
  if (p === '/api/logout' && method === 'POST') {
    if (s) db.prepare('DELETE FROM sessions WHERE id=?').run(s.id);
    clearCookie(res); return json(res, 200, { ok: true });
  }
  if (!s) return json(res, 401, { error: 'Session expired. Please sign in again.' });
  const isSA = s.role === 'Super Admin' && !s.is_account;
  const actor = s.username || s.login_key;

  /* --- shared data (key/value) --- */
  if (p === '/api/data' && method === 'GET') {
    const data = {}, versions = {};
    for (const r of db.prepare('SELECT key,value,version FROM kv').all()) { data[r.key] = r.value; versions[r.key] = r.version; }
    return json(res, 200, { data, versions });
  }
  let m = p.match(/^\/api\/data\/([a-z0-9_]+)$/);
  if (m) {
    const key = m[1];
    if (!KEY_RE.test(key) || CREDENTIAL_KEYS.has(key)) return json(res, 400, { error: 'This data key is not allowed.' });
    if (method === 'PUT') {
      if (SUPERADMIN_ONLY_KEYS.has(key) && !isSA) return json(res, 403, { error: 'Only Super Admin can change this.' });
      const b = await readBody(req);
      if (typeof b.value !== 'string') return json(res, 400, { error: 'value must be a string' });
      const ver = Number(b.version) || 0, row = db.prepare('SELECT version FROM kv WHERE key=?').get(key);
      if ((row ? row.version : 0) !== ver) return json(res, 409, { error: 'conflict', version: row ? row.version : 0 });
      if (row) { db.prepare('UPDATE kv SET value=?,version=version+1,updated_at=?,updated_by=? WHERE key=?').run(b.value, now(), actor, key); return json(res, 200, { version: row.version + 1 }); }
      db.prepare('INSERT INTO kv(key,value,version,updated_at,updated_by) VALUES(?,?,?,?,?)').run(key, b.value, 1, now(), actor);
      return json(res, 200, { version: 1 });
    }
    if (method === 'DELETE') {
      if (!isSA && SUPERADMIN_ONLY_KEYS.has(key)) return json(res, 403, { error: 'Only Super Admin can change this.' });
      db.prepare('DELETE FROM kv WHERE key=?').run(key); audit(actor, 'data-delete', key);
      return json(res, 200, { ok: true });
    }
  }

  /* --- Super Admin: passwords and accounts --- */
  if (p.startsWith('/api/admin/')) {
    if (!isSA) return json(res, 403, { error: 'Only Super Admin can do this.' });

    if (p === '/api/admin/passwords' && method === 'GET') {
      const custom = db.prepare('SELECT key FROM logins').all().map((r) => r.key);
      return json(res, 200, { custom, defaultChanged: getSetting('default_hash') !== getSetting('initial_hash') });
    }
    if (p === '/api/admin/passwords' && method === 'PUT') {
      const b = await readBody(req, 64 * 1024), key = cleanText(b.key, 150), pw = String(b.password || '');
      if (!key || pw.length < 8 || pw.length > 200) return json(res, 400, { error: 'Password must be 8 to 200 characters.' });
      const h = await hashPw(pw);
      db.prepare('INSERT INTO logins(key,salt,hash,updated_at) VALUES(?,?,?,?) ON CONFLICT(key) DO UPDATE SET salt=excluded.salt,hash=excluded.hash,updated_at=excluded.updated_at').run(key, h.salt, h.hash, now());
      dropSessions('login_key=?', [key], key === 'Super Admin' ? s.id : null);
      audit(actor, 'password-reset', key);
      return json(res, 200, { ok: true });
    }
    if (p === '/api/admin/passwords' && method === 'DELETE') {
      const key = cleanText(url.searchParams.get('key'), 150);
      if (!key || key === 'Super Admin') return json(res, 400, { error: 'The Super Admin password cannot be restored to a default.' });
      db.prepare('DELETE FROM logins WHERE key=?').run(key); dropSessions('login_key=?', [key]);
      audit(actor, 'password-default', key); return json(res, 200, { ok: true });
    }
    if (p === '/api/admin/passwords/all' && method === 'POST') {
      const b = await readBody(req, 64 * 1024), pw = String(b.password || '');
      if (pw.length < 8 || pw.length > 200) return json(res, 400, { error: 'Password must be 8 to 200 characters.' });
      const h = await hashPw(pw); putSetting('default_salt', h.salt); putSetting('default_hash', h.hash);
      db.prepare("DELETE FROM logins WHERE key<>'Super Admin'").run();
      db.prepare("DELETE FROM sessions WHERE login_key<>'Super Admin' AND id<>?").run(s.id);
      audit(actor, 'password-reset-all', ''); return json(res, 200, { ok: true });
    }
    if (p === '/api/admin/passwords/restore-all' && method === 'POST') {
      putSetting('default_salt', getSetting('initial_salt')); putSetting('default_hash', getSetting('initial_hash'));
      db.prepare("DELETE FROM logins WHERE key<>'Super Admin'").run();
      db.prepare("DELETE FROM sessions WHERE login_key<>'Super Admin' AND id<>?").run(s.id);
      audit(actor, 'password-restore-all', ''); return json(res, 200, { ok: true });
    }
    if (p === '/api/admin/accounts' && method === 'GET') {
      return json(res, 200, { accounts: db.prepare('SELECT username,display,role,dept,created_at FROM accounts ORDER BY created_at').all() });
    }
    if (p === '/api/admin/accounts' && method === 'POST') {
      const b = await readBody(req, 64 * 1024);
      const username = cleanText(b.username, 80).toLowerCase(), display = cleanText(b.display, 120), role = cleanText(b.role, 80), dept = cleanText(b.dept, 60), pw = String(b.password || '');
      if (!username || !display || !role) return json(res, 400, { error: 'Enter username, display name and role.' });
      if (pw.length < 8 || pw.length > 200) return json(res, 400, { error: 'Use a password of at least 8 characters.' });
      if (role === 'Super Admin' || /^superadmin/.test(username)) return json(res, 400, { error: 'That username or role is reserved.' });
      if (db.prepare('SELECT 1 FROM accounts WHERE username=?').get(username)) return json(res, 409, { error: 'That username already exists.' });
      const h = await hashPw(pw);
      db.prepare('INSERT INTO accounts(username,display,role,dept,salt,hash,created_at) VALUES(?,?,?,?,?,?,?)').run(username, display, role, dept, h.salt, h.hash, now());
      audit(actor, 'account-create', username + ' / ' + role); return json(res, 200, { ok: true });
    }
    if (p === '/api/admin/accounts/password' && method === 'PUT') {
      const b = await readBody(req, 64 * 1024), username = cleanText(b.username, 80).toLowerCase(), pw = String(b.password || '');
      if (pw.length < 8 || pw.length > 200) return json(res, 400, { error: 'Password must be 8 to 200 characters.' });
      if (!db.prepare('SELECT 1 FROM accounts WHERE username=?').get(username)) return json(res, 404, { error: 'Account not found.' });
      const h = await hashPw(pw);
      db.prepare('UPDATE accounts SET salt=?,hash=? WHERE username=?').run(h.salt, h.hash, username);
      dropSessions('login_key=?', ['acct:' + username]); audit(actor, 'account-password-reset', username);
      return json(res, 200, { ok: true });
    }
    if (p === '/api/admin/accounts' && method === 'DELETE') {
      const username = cleanText(url.searchParams.get('username'), 80).toLowerCase();
      db.prepare('DELETE FROM accounts WHERE username=?').run(username); dropSessions('login_key=?', ['acct:' + username]);
      audit(actor, 'account-remove', username); return json(res, 200, { ok: true });
    }
    if (p === '/api/admin/audit' && method === 'GET') {
      return json(res, 200, { audit: db.prepare('SELECT at,actor,action,detail FROM audit ORDER BY id DESC LIMIT 200').all() });
    }
  }
  return json(res, 404, { error: 'Not found.' });
}

/* ---------- server ---------- */
const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://localhost');
    if (url.pathname.startsWith('/api/')) return await api(req, res, url);
    if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); return res.end(); }
    if (url.pathname === '/' || url.pathname === '/index.html') return serveIndex(req, res);
    if (url.pathname === '/favicon.ico') { res.writeHead(204); return res.end(); }
    res.writeHead(404, { 'Content-Type': 'text/plain' }); res.end('Not found');
  } catch (e) {
    const code = e.code === 413 || e.code === 400 ? e.code : 500;
    if (code === 500) console.error(e);
    if (!res.headersSent) json(res, code, { error: code === 500 ? 'Server error.' : e.message });
  }
});

(async () => {
  const cmd = process.argv[2];
  await initSecrets();
  if (cmd === 'reset-superadmin') {
    const pw = process.argv[3];
    if (!pw || pw.length < 8) { console.error('Usage: node server.js reset-superadmin <new password, 8+ characters>'); process.exit(1); }
    const h = await hashPw(pw);
    db.prepare('UPDATE logins SET salt=?,hash=?,updated_at=? WHERE key=?').run(h.salt, h.hash, now(), 'Super Admin');
    db.prepare("DELETE FROM sessions WHERE login_key='Super Admin'").run();
    console.log('Super Admin password updated.'); process.exit(0);
  }
  server.listen(PORT, () => console.log(`Mauli portal running on port ${PORT}  (data: ${DATA_DIR})`));
})();
