# Mauli College Portal – deploy + APK guide

Frontend (`public/index.html`) and backend (`server.js`, Node 22 + SQLite) are **one app**:
the server serves the page and the page calls `/api/...` on the same address, so they are
already connected. Deploy once and both work. The APK is a thin Android shell that opens your
deployed address (cookies/login keep working because it is the same origin).

## 1. Deploy the server (needs a persistent disk, because data is stored in SQLite)

### Option A – Render (easiest, ~US$7/month; free tier loses data on restart)
1. Create a GitHub repo and push this whole folder.
2. render.com → New → Blueprint → pick the repo. It reads `render.yaml`.
3. When asked, set `SUPERADMIN_PASSWORD` and `DEFAULT_PASSWORD` (the shared password for all other logins).
4. After deploy you get `https://mauli-portal.onrender.com` (yours will differ). Open it and sign in.

### Option B – Fly.io
Follow the comments at the top of `fly.toml`.

### Option C – Any VPS
`docker build -t mauli . && docker run -d -p 80:3000 -v mauli-data:/data -e SUPERADMIN_PASSWORD=... -e DEFAULT_PASSWORD=... mauli`
(put HTTPS in front, e.g. Caddy). Back up the `/data` volume regularly.

Forgot the Super Admin password: `node server.js reset-superadmin <new password>`.

## 2. Build the APK (needs your deployed URL from step 1)
1. Push the repo to GitHub (already done if you used Render).
2. GitHub → Actions → **Build APK** → Run workflow → paste your URL (https://…).
3. Download `mauli-portal-apk` from the finished run, unzip, send `app-debug.apk` to phones and install
   (allow "install unknown apps").

Local build instead: `cd android && gradle assembleDebug -PAPP_URL=https://your-url` (needs JDK 17 + Android SDK).
The URL must be **https**. To publish on Play Store you need a release-signed build (ask and I'll add it).

## Local test
`DEFAULT_PASSWORD=x12345678 SUPERADMIN_PASSWORD=y12345678 node server.js` → http://localhost:3000
